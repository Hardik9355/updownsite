from django.contrib import admin
from .models import Urls
admin.site.register(Urls)
# admin.site.register(status_code)

# Register your models here.
