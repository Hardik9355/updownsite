from django.urls import path,include
from rest_framework import routers
from .import views
from .views import *

router = routers.DefaultRouter()
urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
    path('urllink/', url_status, name="url" ),
    path('', views.url_status)
    # path('urllink/str:status>', result, name='status' ),
]