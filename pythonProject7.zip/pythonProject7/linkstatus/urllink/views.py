from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from .models import Urls
from rest_framework.decorators import api_view
from django.template import loader
import requests


@api_view(['GET'])
def url_status(request):
    try:
        MAX_OBJECTS = 100
        links = Urls.objects.all()[:MAX_OBJECTS]
        link_status = []
        for link in links:
            link_status.append({'link': link, 'status': 'Up' if requests.get(link).status_code == 200 else 'Down'})

            print(link_status)
        return render(request, 'urllink/index.html', {'all_links': link_status})
    except Exception as e:
        print(e)
        return HttpResponse('error')
